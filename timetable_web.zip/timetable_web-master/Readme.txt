Recently, because of the Covid-19 Virus, a freshman has entered, but he is attending classes at home without attending school. 
When I enrolled in the second semester, I thought it would be helpful to know the location of the classroom in class 
and the route to the classroom when preparing the timetable. So, we added timetable function, map circulation function, 
and circular bus notification function, and added a calendar function to know the school schedule.
