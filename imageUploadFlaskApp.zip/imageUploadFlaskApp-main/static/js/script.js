console.log('scripts.js loaded');
